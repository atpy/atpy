import atpy

t = atpy.Table()
t.table_name = table_name='group1/group2/table'
t.add_column('test',[1,2,3])
t.write('test3.hdf5', overwrite=True)
t.write('test4.hdf5', ignore_groups=True, overwrite=True)

ts = atpy.TableSet()
ts.append(t)
ts.write('test.hdf5', overwrite=True)
ts.write('test2.hdf5', ignore_groups=True, overwrite=True)
